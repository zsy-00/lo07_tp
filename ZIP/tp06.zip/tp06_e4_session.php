<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php session_start();
$_SESSION['nom_prenom']="Zhang Shiyuan";
$_SESSION['module']=array("MATH03","PHYS11","SC02","FOS4","FB2E","LO07","NF05A");
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       
       <a href="lo07_analyse_superglobales.php">lo07_analyse_superglobales.php</a> 
       
    </body>
</html>
