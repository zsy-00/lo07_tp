<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php setcookie("nom", "zhang");
 setcookie("prénom", "shiyuan");
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>cookie2</title>
        
    </head>
    <body>
        <a href="lo07_analyse_superglobales.php">lo07_analyse_superglobales.php</a> 
    </body>
</html>
