<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
        <?php 
$dsn = 'mysql:dbname=zhangsh4;host=localhost;charset=utf8';
$username = 'zhangsh4';
$password = 'spZx9w2k';


?>   

