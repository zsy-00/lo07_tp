        <?php
        function panel_head($title){
    echo"<div class='panel panel-primary'>
            <div class='panel-heading'>
                <h3 class='panel-title'>
                    <b>".$title."</b>
                </h3>
            </div>       
         </div>";    
}
        ?>
