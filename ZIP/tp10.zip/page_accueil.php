<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php include 'fragmentHeader.html';?>
<body>
    <div class="container" >
        <?php
        include 'fragmentMenu.html';
        include 'fragmentJumbotron.html';
        include 'fragmentFooter.html';
        ?>
    